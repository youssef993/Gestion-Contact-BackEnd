package com.ant.gc.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ant.gc.entities.Contact;
import com.ant.gc.model.MessageResponse;
import com.ant.gc.repositories.ContactRepository;
import com.ant.gc.services.ContactService;

@Service
public class ContactServiceImpl implements ContactService {

	@Autowired
	private ContactRepository contactRepository;
	
	@Transactional
	@Override
	public MessageResponse save(Contact contact) {
		boolean exist = contactRepository.existsByEmail(contact.getEmail());
		if(exist) {
			return new MessageResponse(false, "EMAIL Existant!!!");
		}
		contactRepository.save(contact);
		return new MessageResponse(true, "Contact ajouteR AVEC SUCCES");
	}

	@Transactional
	@Override
	public MessageResponse update(Contact contact) {
		boolean exist= contactRepository.existsByEmailAndId(contact.getEmail(), contact.getId());
		if(!exist) {
			exist = contactRepository.existsByEmail(contact.getEmail());
			if(exist) {
				return new MessageResponse(false, "EMAIL Existant!!!");
			}
			
		}
		
		contactRepository.save(contact);
		return new MessageResponse(true, "Contact modifier AVEC SUCCES");
	}

	@Transactional
	@Override
	public MessageResponse delete(Integer id) {
		boolean exist= contactRepository.existsById(id);
		if(!exist) {
			return new MessageResponse(false, "Contact Not Found!!!");
		}
		contactRepository.deleteById(id);
		return new MessageResponse(true, "Contact supprimer AVEC SUCCES");
	}

	@Override
	public List<Contact> findAll() {
		// TODO Auto-generated method stub
		return contactRepository.findAll();
	}

	@Override
	public Contact findById(Integer id) {
		// TODO Auto-generated method stub
		return contactRepository.findById(id).orElse(null);
	}

}
