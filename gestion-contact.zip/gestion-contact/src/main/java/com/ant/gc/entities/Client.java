package com.ant.gc.entities;

import javax.persistence.Entity;

import lombok.Data;

@Entity
@Data
public class Client extends Contact {

}
