package com.ant.gc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.ant.gc.entities.Users;
import com.ant.gc.model.MessageResponse;
import com.ant.gc.repositories.ClientRepository;
import com.ant.gc.repositories.ContactRepository;
import com.ant.gc.repositories.UsersRepository;
import com.ant.gc.services.UsersService;

@Component
public class Test implements CommandLineRunner {

	
	
	@Autowired
	private ContactRepository contactRepository;
	@Autowired
	private ClientRepository  clientRepository;
	@Autowired
	private UsersRepository  usersRepository;
	@Autowired
	private UsersService  usersService;
	
	@Override
	public void run(String... args) throws Exception {
//		Users user= new Users();
//		user.setNom("youssef1");
//		user.setPrenom("youssef1");
//		user.setEmail("youssef1");
//		user.setUsername("youssef1");
//		user.setPassword("youssef1");
//		user.setRole("User");
//		MessageResponse result =usersService.save(user);
//		usersRepository.deleteAllInBatch();
		
		// TODO Auto-generated method stub
//		contactRepository.findAll();
//		List<Contact> list=  contactRepository.findByNom("Ali");
//		Client clt = new Client();
//		clt.setNom("Youssef");
//		clt.setPrenom("Youssef");
//		clt.setEmail("Youssef");
//		clientRepository.save(clt);
//		Users cllt = new Users();
//		cllt.setNom("Youssef");
//		cllt.setPrenom("Youssef");
//		cllt.setEmail("Youssef");
//		cllt.setUsername("Youssef");
//		cllt.setPassword("Youssef");
//		usersRepository.save(cllt);
	}
	
	

}
