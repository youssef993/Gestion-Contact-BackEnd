package com.ant.gc.sbmail;

public class MyConstants {

    // Replace with your email here:  
    public static final String MY_EMAIL = "najet.alouini@gmail.com";
 
    // Replace password!!
    public static final String MY_PASSWORD = "awledzayer";
 
    // And receiver!
    public static final String FRIEND_EMAIL = "youssef.zairi93@gmail.com";
}
