package com.ant.gc;

import java.util.HashSet;

public class Foo {
	 
	public static void main(String args[]) {
	String s1 = new String("2");
	String s2 = new String("2"); 
	HashSet< Object > hs = new HashSet< Object >();
	hs.add(s1);
	hs.add(s2);
	System.out.print(hs.size());
	}}