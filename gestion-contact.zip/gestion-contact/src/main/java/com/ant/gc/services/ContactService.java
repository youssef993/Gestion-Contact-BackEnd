package com.ant.gc.services;

import java.util.List;

import com.ant.gc.entities.Contact;
import com.ant.gc.model.MessageResponse;

public interface ContactService {
	public MessageResponse save(Contact contact);
	public MessageResponse update(Contact contact);
	public MessageResponse delete(Integer id);
	public List<Contact> findAll();
	public Contact findById(Integer id);
}
