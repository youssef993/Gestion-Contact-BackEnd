package com.ant.gc.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ant.gc.entities.Users;
import com.ant.gc.model.MessageResponse;
import com.ant.gc.model.PasswordDTO;
import com.ant.gc.repositories.ContactRepository;
import com.ant.gc.repositories.UsersRepository;
import com.ant.gc.services.UsersService;

@Service

public class UsersServiceImpl implements UsersService{
	@Autowired
	private UsersRepository usersRepository;
	@Autowired
	private ContactRepository contactRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Transactional
	@Override
	public MessageResponse save(Users user) {
		boolean exist = contactRepository.existsByEmail(user.getEmail());
		if (exist) {
			return new MessageResponse(false, "EMAIL Existant!!!");
		}
		exist = usersRepository.existsByUsername(user.getUsername());
		if (exist) {
			return new MessageResponse(false, "USERNAME EXISTENT");
		}
		String cryptedPwd = passwordEncoder.encode(user.getPassword());
		user.setPassword(cryptedPwd);
		usersRepository.save(user);

		return new MessageResponse(true, "Ajout effectué avec succés");
	}

	@Transactional
	@Override
	public MessageResponse update(Users user) {
		boolean exist = contactRepository.existsByEmailAndId(user.getEmail(), user.getId());
		if (!exist) {
			exist = contactRepository.existsByEmail(user.getEmail());
			if (exist) {
				return new MessageResponse(false, "EMAIL Existant!!!");
			}
		}
		exist = usersRepository.existsByUsernameAndId(user.getUsername(), user.getId());
		if (!exist) {
			exist = usersRepository.existsByUsername(user.getUsername());
			if (exist) {
				return new MessageResponse(false, "USERNAME EXISTENT");
			}
		}
		usersRepository.save(user);
		return new MessageResponse(true, "modification effectué avec succés");
	}

	@Transactional
	@Override
	public MessageResponse delete(Integer id) {
		boolean exist = usersRepository.existsById(id);
		if (!exist) {
			return new MessageResponse(false, "user not found");
		}
		usersRepository.deleteById(id);
		return new MessageResponse(true, "Suppression effectué avec succés");
	}

	@Transactional(readOnly = true)
	@Override
	public List<Users> findAll() {

		return usersRepository.findAll();
	}
	@Override
	public Users findById(Integer id) {
		return usersRepository.findById(id).orElse(null);
		
	}

	@Transactional
	@Override
	public MessageResponse changePassword(PasswordDTO pswdto) {
		Users user = usersRepository.findById(pswdto.getId()).orElse(null);
		if (user == null) {
			return new MessageResponse(false, "user not found");
		}
		boolean valid = passwordEncoder.matches(pswdto.getOldPassword(), user.getPassword());
		if (!valid) {
			return new MessageResponse(false, "Réentrer la mot de passe acctuelle!!!");
		}
		String cryptedPwd = passwordEncoder.encode(pswdto.getNewPassword());
		user.setPassword(cryptedPwd);
		usersRepository.save(user);
		return new MessageResponse(true, "Mot de passe modifier avec success!!!");
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		return usersRepository.findOneByUsername(username);
	}

}
